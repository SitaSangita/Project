package in.sita.sangitaTech.DTO;

import lombok.Data;

@Data
public class CounsellorDashboradDTO {
	private Integer totalEnquiry;
	private Integer openEnquiry;
	private Integer enrolledEnquiry;
	private Integer lostEnquiry;

}
