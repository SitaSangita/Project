package in.sita.sangitaTech.DTO;

import lombok.Data;

@Data
public class CounsellorDTO {

	private Integer counsellorId;
	private String name;
	private Long phoneNo;
	private String email;
	private String password;
}
